package Modelo;

/**
 * @version 1.0
 * @created 19-jul.-2019 12:48:25 p. m.
 */
public class Afiliado extends Usuario {

	private Categoria categoria;
	private String estado;
	private String estadomulta;
	private String tipoafiliacion;
	public Categoria m_Categoria;

	public Afiliado(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	public Categoria getcategoria(){
		return categoria;
	}

	public String getestado(){
		return estado;
	}

	public String getestadomulta(){
		return estadomulta;
	}

	public String gettipoafiliacion(){
		return tipoafiliacion;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setcategoria(Categoria newVal){
		categoria = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setestado(String newVal){
		estado = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setestadomulta(String newVal){
		estadomulta = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void settipoafiliacion(String newVal){
		tipoafiliacion = newVal;
	}
}//end Afiliado