package Modelo;

/**
 * @author camilo
 * @version 1.0
 * @created 19-jul.-2019 12:48:25 p. m.
 */
public class TipoCita {

	private int duracion;
	private int idtipocita;

	public TipoCita(){

	}

	public void finalize() throws Throwable {

	}
	public int getduracion(){
		return duracion;
	}

	public int getidtipocita(){
		return idtipocita;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setduracion(int newVal){
		duracion = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setidtipocita(int newVal){
		idtipocita = newVal;
	}
}//end TipoCita