package Modelo;

/**
 * @author camilo
 * @version 1.0
 * @created 19-jul.-2019 12:48:25 p. m.
 */
public class Multa {

	private String estado;
	private int idmulta;
	private int valormulta;

	public Multa(){

	}

	public void finalize() throws Throwable {

	}
	public String getestado(){
		return estado;
	}

	public int getidmulta(){
		return idmulta;
	}

	public int getvalormulta(){
		return valormulta;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setestado(String newVal){
		estado = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setidmulta(int newVal){
		idmulta = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setvalormulta(int newVal){
		valormulta = newVal;
	}
}//end Multa