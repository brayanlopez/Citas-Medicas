package Modelo;

/**
 * @author camilo
 * @version 1.0
 * @created 19-jul.-2019 12:48:25 p. m.
 */
public class Agenda {

	private Cita cita;
	private String estado;
	private String fecha;
	private int horafinal;
	private int horainicial;
	private int idagenda;
	private Medico medico;
	private TipoCita tipocita;
	public TipoCita m_TipoCita;
	public Medico m_Medico;
	public Cita m_Cita;

	public Agenda(){

	}

	public void finalize() throws Throwable {

	}
	public Cita getcita(){
		return cita;
	}

	public String getestado(){
		return estado;
	}

	public String getfecha(){
		return fecha;
	}

	public int gethorafinal(){
		return horafinal;
	}

	public int gethorainicial(){
		return horainicial;
	}

	public int getidagenda(){
		return idagenda;
	}

	public Medico getmedico(){
		return medico;
	}

	public TipoCita gettipocita(){
		return tipocita;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setcita(Cita newVal){
		cita = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setestado(String newVal){
		estado = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setfecha(String newVal){
		fecha = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void sethorafinal(int newVal){
		horafinal = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void sethorainicial(int newVal){
		horainicial = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setidagenda(int newVal){
		idagenda = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setmedico(Medico newVal){
		medico = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void settipocita(TipoCita newVal){
		tipocita = newVal;
	}
}//end Agenda