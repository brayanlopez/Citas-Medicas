package Modelo;

/**
 * Representa la sede del consultorio
 * @author camilo
 * @version 1.0
 * @created 19-jul.-2019 12:48:25 p. m.
 */
public class Sede {

	/**
	 * Es la unbicacion en la ciudad
	 */
	private String direccion;
	/**
	 * Es el identificador de la sede
	 */
	private int idsede;
	/**
	 * Es la asignacion dada con caracteres
	 */
	private String nombre;
	/**
	 * Es el numero de contacto para comunicarse con la sede
	 */
	private int telefono;

	public Sede(){

	}

	public void finalize() throws Throwable {

	}
	public String getdireccion(){
		return direccion;
	}

	public int getidsede(){
		return idsede;
	}

	public String getnombre(){
		return nombre;
	}

	public int gettelefono(){
		return telefono;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setdireccion(String newVal){
		direccion = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setidsede(int newVal){
		idsede = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setnombre(String newVal){
		nombre = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void settelefono(int newVal){
		telefono = newVal;
	}
}//end Sede