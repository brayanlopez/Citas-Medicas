package Modelo;

/**
 * @author camilo
 * @version 1.0
 * @created 19-jul.-2019 12:48:25 p. m.
 */
public class Categoria {

	private int idcategoria;
	private int valorcopago;
	private int valormulta;

	public Categoria(){

	}

	public void finalize() throws Throwable {

	}
	public int getidcategoria(){
		return idcategoria;
	}

	public int getvalorcopago(){
		return valorcopago;
	}

	public int getvalormulta(){
		return valormulta;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setidcategoria(int newVal){
		idcategoria = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setvalorcopago(int newVal){
		valorcopago = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setvalormulta(int newVal){
		valormulta = newVal;
	}
}//end Categoria