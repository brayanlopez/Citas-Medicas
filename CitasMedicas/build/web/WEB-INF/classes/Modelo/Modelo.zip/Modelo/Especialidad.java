package Modelo;

/**
 * @author camilo
 * @version 1.0
 * @created 19-jul.-2019 12:48:25 p. m.
 */
public class Especialidad {

	private int codigo;
	private String nombre;

	public Especialidad(){

	}

	public void finalize() throws Throwable {

	}
	public int getcodigo(){
		return codigo;
	}

	public String getnombre(){
		return nombre;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setcodigo(int newVal){
		codigo = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setnombre(String newVal){
		nombre = newVal;
	}
}//end Especialidad