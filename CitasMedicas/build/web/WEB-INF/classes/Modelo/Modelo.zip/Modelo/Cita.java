package Modelo;

/**
 * @author camilo
 * @version 1.0
 * @created 19-jul.-2019 12:48:25 p. m.
 */
public class Cita {

	private int costo;
	private String diagnostico;
	private String estado;
	private String fecha;
	private int idcita;
	private Multa multa;
	private String prescripcion;
	public Afiliado m_Afiliado;
	public Multa m_Multa;

	public Cita(){

	}

	public void finalize() throws Throwable {

	}
	public int getcosto(){
		return costo;
	}

	public String getdiagnostico(){
		return diagnostico;
	}

	public String getestado(){
		return estado;
	}

	public String getfecha(){
		return fecha;
	}

	public int getidcita(){
		return idcita;
	}

	public Multa getmulta(){
		return multa;
	}

	public String getprescripcion(){
		return prescripcion;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setcosto(int newVal){
		costo = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setdiagnostico(String newVal){
		diagnostico = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setestado(String newVal){
		estado = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setfecha(String newVal){
		fecha = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setidcita(int newVal){
		idcita = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setmulta(Multa newVal){
		multa = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setprescripcion(String newVal){
		prescripcion = newVal;
	}
}//end Cita