package Modelo;

/**
 * @author camilo
 * @version 1.0
 * @created 19-jul.-2019 12:48:25 p. m.
 */
public class Medico extends Usuario {

	private Consultorio consultorio;
	private Especialidad especialidad;
	private int franja;
	private int registromedico;
	public Especialidad m_Especialidad;
	public Consultorio m_Consultorio;

	public Medico(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	public Consultorio getconsultorio(){
		return consultorio;
	}

	public Especialidad getespecialidad(){
		return especialidad;
	}

	public int getfranja(){
		return franja;
	}

	public int getregistromedico(){
		return registromedico;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setconsultorio(Consultorio newVal){
		consultorio = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setespecialidad(Especialidad newVal){
		especialidad = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setfranja(int newVal){
		franja = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setregistromedico(int newVal){
		registromedico = newVal;
	}
}//end Medico