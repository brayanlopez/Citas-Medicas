package Modelo;

/**
 * @author camilo
 * @version 1.0
 * @created 19-jul.-2019 12:48:25 p. m.
 */
public class Consultorio {

	private String descripcionequipo;
	private int id;
	private Sede sede;
	private String tipo;
	public Sede m_Sede;

	public Consultorio(){

	}

	public void finalize() throws Throwable {

	}
	public String getdescripcionequipo(){
		return descripcionequipo;
	}

	public int getid(){
		return id;
	}

	public Sede getsede(){
		return sede;
	}

	public String gettipo(){
		return tipo;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setdescripcionequipo(String newVal){
		descripcionequipo = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setid(int newVal){
		id = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setsede(Sede newVal){
		sede = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void settipo(String newVal){
		tipo = newVal;
	}
}//end Consultorio