package Modelo;

/**
 * @version 1.0
 * @created 19-jul.-2019 12:48:25 p. m.
 */
public class Usuario {

	private String apellido;
	private String correo;
	private int fechaNacimiento;
	private String nombre;
	private int numeroIdentificacion;
	private String Sexo;
	private int telContacto;
	private int telPersonal;
	private String tipoIdentificacion;

	public Usuario(){

	}

	public void finalize() throws Throwable {

	}
	public String getapellido(){
		return apellido;
	}

	public String getcorreo(){
		return correo;
	}

	public int getfechaNacimiento(){
		return fechaNacimiento;
	}

	public String getnombre(){
		return nombre;
	}

	public int getnumeroIdentificacion(){
		return numeroIdentificacion;
	}

	public String getSexo(){
		return Sexo;
	}

	public int gettelContacto(){
		return telContacto;
	}

	public int gettelPersonal(){
		return telPersonal;
	}

	public String gettipoIdentificacion(){
		return tipoIdentificacion;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setapellido(String newVal){
		apellido = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setcorreo(String newVal){
		correo = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setfechaNacimiento(int newVal){
		fechaNacimiento = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setnombre(String newVal){
		nombre = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setnumeroIdentificacion(int newVal){
		numeroIdentificacion = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setSexo(String newVal){
		Sexo = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void settelContacto(int newVal){
		telContacto = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void settelPersonal(int newVal){
		telPersonal = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void settipoIdentificacion(String newVal){
		tipoIdentificacion = newVal;
	}
}//end Usuario